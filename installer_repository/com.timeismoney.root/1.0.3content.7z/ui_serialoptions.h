/********************************************************************************
** Form generated from reading UI file 'serialoptions.ui'
**
** Created by: Qt User Interface Compiler version 6.2.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SERIALOPTIONS_H
#define UI_SERIALOPTIONS_H

#include <QtCore/QVariant>
#include <QtWidgets/QAbstractButton>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SerialOptions
{
public:
    QSplitter *splitter_2;
    QSplitter *splitter;
    QWidget *layoutWidget_3;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label;
    QComboBox *comboBox;
    QWidget *layoutWidget_2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QComboBox *comboBox_2;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *SerialOptions)
    {
        if (SerialOptions->objectName().isEmpty())
            SerialOptions->setObjectName(QString::fromUtf8("SerialOptions"));
        SerialOptions->resize(369, 159);
        splitter_2 = new QSplitter(SerialOptions);
        splitter_2->setObjectName(QString::fromUtf8("splitter_2"));
        splitter_2->setGeometry(QRect(10, 30, 271, 79));
        splitter_2->setOrientation(Qt::Vertical);
        splitter = new QSplitter(splitter_2);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setOrientation(Qt::Vertical);
        layoutWidget_3 = new QWidget(splitter);
        layoutWidget_3->setObjectName(QString::fromUtf8("layoutWidget_3"));
        horizontalLayout_3 = new QHBoxLayout(layoutWidget_3);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(layoutWidget_3);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout_3->addWidget(label);

        comboBox = new QComboBox(layoutWidget_3);
        comboBox->setObjectName(QString::fromUtf8("comboBox"));

        horizontalLayout_3->addWidget(comboBox);

        splitter->addWidget(layoutWidget_3);
        layoutWidget_2 = new QWidget(splitter);
        layoutWidget_2->setObjectName(QString::fromUtf8("layoutWidget_2"));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget_2);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(layoutWidget_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_2->addWidget(label_2);

        comboBox_2 = new QComboBox(layoutWidget_2);
        comboBox_2->setObjectName(QString::fromUtf8("comboBox_2"));

        horizontalLayout_2->addWidget(comboBox_2);

        splitter->addWidget(layoutWidget_2);
        splitter_2->addWidget(splitter);
        buttonBox = new QDialogButtonBox(splitter_2);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        splitter_2->addWidget(buttonBox);

        retranslateUi(SerialOptions);
        QObject::connect(buttonBox, &QDialogButtonBox::accepted, SerialOptions, qOverload<>(&QDialog::accept));
        QObject::connect(buttonBox, &QDialogButtonBox::rejected, SerialOptions, qOverload<>(&QDialog::reject));

        QMetaObject::connectSlotsByName(SerialOptions);
    } // setupUi

    void retranslateUi(QDialog *SerialOptions)
    {
        SerialOptions->setWindowTitle(QCoreApplication::translate("SerialOptions", "Port Options", nullptr));
        label->setText(QCoreApplication::translate("SerialOptions", "Port:", nullptr));
        label_2->setText(QCoreApplication::translate("SerialOptions", "Baudrate:", nullptr));
    } // retranslateUi

};

namespace Ui {
    class SerialOptions: public Ui_SerialOptions {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SERIALOPTIONS_H
