/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.2.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../QtProjects/TimeIsMoney/src/mainwindow.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.2.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    const uint offsetsAndSize[44];
    char stringdata0[353];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 10), // "MainWindow"
QT_MOC_LITERAL(11, 6), // "runCmd"
QT_MOC_LITERAL(18, 0), // ""
QT_MOC_LITERAL(19, 11), // "std::string"
QT_MOC_LITERAL(31, 3), // "val"
QT_MOC_LITERAL(35, 9), // "startTask"
QT_MOC_LITERAL(45, 10), // "cancelTask"
QT_MOC_LITERAL(56, 18), // "clientname_changed"
QT_MOC_LITERAL(75, 16), // "taskname_changed"
QT_MOC_LITERAL(92, 13), // "price_changed"
QT_MOC_LITERAL(106, 16), // "taskinfo_changed"
QT_MOC_LITERAL(123, 10), // "closeEvent"
QT_MOC_LITERAL(134, 12), // "QCloseEvent*"
QT_MOC_LITERAL(147, 5), // "event"
QT_MOC_LITERAL(153, 15), // "usbPort_Changed"
QT_MOC_LITERAL(169, 26), // "usbPort_ChangeDialogClosed"
QT_MOC_LITERAL(196, 27), // "on_actionOverview_triggered"
QT_MOC_LITERAL(224, 33), // "on_actionCreate_Invoice_trigg..."
QT_MOC_LITERAL(258, 23), // "on_actionPort_triggered"
QT_MOC_LITERAL(282, 23), // "on_actionInfo_triggered"
QT_MOC_LITERAL(306, 23), // "on_startTaskBtn_clicked"
QT_MOC_LITERAL(330, 22) // "on_stopTaskBtn_clicked"

    },
    "MainWindow\0runCmd\0\0std::string\0val\0"
    "startTask\0cancelTask\0clientname_changed\0"
    "taskname_changed\0price_changed\0"
    "taskinfo_changed\0closeEvent\0QCloseEvent*\0"
    "event\0usbPort_Changed\0usbPort_ChangeDialogClosed\0"
    "on_actionOverview_triggered\0"
    "on_actionCreate_Invoice_triggered\0"
    "on_actionPort_triggered\0on_actionInfo_triggered\0"
    "on_startTaskBtn_clicked\0on_stopTaskBtn_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      16,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,  110,    2, 0x08,    1 /* Private */,
       5,    0,  113,    2, 0x08,    3 /* Private */,
       6,    0,  114,    2, 0x08,    4 /* Private */,
       7,    1,  115,    2, 0x08,    5 /* Private */,
       8,    1,  118,    2, 0x08,    7 /* Private */,
       9,    1,  121,    2, 0x08,    9 /* Private */,
      10,    0,  124,    2, 0x08,   11 /* Private */,
      11,    1,  125,    2, 0x08,   12 /* Private */,
      14,    1,  128,    2, 0x08,   14 /* Private */,
      15,    0,  131,    2, 0x08,   16 /* Private */,
      16,    0,  132,    2, 0x08,   17 /* Private */,
      17,    0,  133,    2, 0x08,   18 /* Private */,
      18,    0,  134,    2, 0x08,   19 /* Private */,
      19,    0,  135,    2, 0x08,   20 /* Private */,
      20,    0,  136,    2, 0x08,   21 /* Private */,
      21,    0,  137,    2, 0x08,   22 /* Private */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    4,
    QMetaType::Void, QMetaType::QString,    4,
    QMetaType::Void, QMetaType::QString,    4,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 12,   13,
    QMetaType::Void, QMetaType::QString,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->runCmd((*reinterpret_cast< std::add_pointer_t<std::string>>(_a[1]))); break;
        case 1: _t->startTask(); break;
        case 2: _t->cancelTask(); break;
        case 3: _t->clientname_changed((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 4: _t->taskname_changed((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 5: _t->price_changed((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 6: _t->taskinfo_changed(); break;
        case 7: _t->closeEvent((*reinterpret_cast< std::add_pointer_t<QCloseEvent*>>(_a[1]))); break;
        case 8: _t->usbPort_Changed((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 9: _t->usbPort_ChangeDialogClosed(); break;
        case 10: _t->on_actionOverview_triggered(); break;
        case 11: _t->on_actionCreate_Invoice_triggered(); break;
        case 12: _t->on_actionPort_triggered(); break;
        case 13: _t->on_actionInfo_triggered(); break;
        case 14: _t->on_startTaskBtn_clicked(); break;
        case 15: _t->on_stopTaskBtn_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.offsetsAndSize,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_MainWindow_t
, QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const std::string &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QCloseEvent *, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>


>,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 16)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 16;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
