/********************************************************************************
** Form generated from reading UI file 'invoice.ui'
**
** Created by: Qt User Interface Compiler version 6.2.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_INVOICE_H
#define UI_INVOICE_H

#include <QtCore/QLocale>
#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCalendarWidget>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Invoice
{
public:
    QTabWidget *tabWidget;
    QWidget *tab;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLabel *label_startDate;
    QTabWidget *tab_date;
    QWidget *tab_startDate;
    QCalendarWidget *calendarStart;
    QWidget *tab_endDate;
    QCalendarWidget *calendarEnd;
    QWidget *layoutWidget_2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_3;
    QLabel *label_endDate;
    QWidget *layoutWidget_3;
    QVBoxLayout *verticalLayout;
    QLabel *label_5;
    QComboBox *comboBoxClients;
    QPushButton *btnGenerate;
    QWidget *tab_format;
    QSplitter *splitter;
    QWidget *widget;
    QHBoxLayout *horizontalLayout_7;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_6;
    QLineEdit *lineEdit_tax;
    QVBoxLayout *verticalLayout_6;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_7;
    QLineEdit *lineEdit_userCurrency;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_8;
    QLineEdit *lineEdit_clientCurrency;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_9;
    QLineEdit *lineEdit_exchange;
    QWidget *widget1;
    QVBoxLayout *verticalLayout_5;
    QVBoxLayout *verticalLayout_4;
    QVBoxLayout *verticalLayout_2;
    QFrame *line;
    QLabel *label_2;
    QTextEdit *textEdit_header;
    QFrame *line_3;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_4;
    QTextEdit *textEdit_footer;
    QFrame *line_2;
    QPushButton *btnSaveSettings;

    void setupUi(QWidget *Invoice)
    {
        if (Invoice->objectName().isEmpty())
            Invoice->setObjectName(QString::fromUtf8("Invoice"));
        Invoice->resize(514, 425);
        tabWidget = new QTabWidget(Invoice);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setGeometry(QRect(0, 0, 511, 421));
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        layoutWidget = new QWidget(tab);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 100, 230, 19));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        label_startDate = new QLabel(layoutWidget);
        label_startDate->setObjectName(QString::fromUtf8("label_startDate"));
        label_startDate->setMinimumSize(QSize(150, 0));
        label_startDate->setBaseSize(QSize(30, 0));
        label_startDate->setTextInteractionFlags(Qt::NoTextInteraction);

        horizontalLayout->addWidget(label_startDate);

        tab_date = new QTabWidget(tab);
        tab_date->setObjectName(QString::fromUtf8("tab_date"));
        tab_date->setGeometry(QRect(0, 160, 521, 241));
        tab_date->setFocusPolicy(Qt::NoFocus);
        tab_startDate = new QWidget();
        tab_startDate->setObjectName(QString::fromUtf8("tab_startDate"));
        tab_startDate->setFocusPolicy(Qt::TabFocus);
        calendarStart = new QCalendarWidget(tab_startDate);
        calendarStart->setObjectName(QString::fromUtf8("calendarStart"));
        calendarStart->setGeometry(QRect(5, 10, 501, 191));
        calendarStart->setLocale(QLocale(QLocale::English, QLocale::Europe));
        calendarStart->setGridVisible(true);
        tab_date->addTab(tab_startDate, QString());
        tab_endDate = new QWidget();
        tab_endDate->setObjectName(QString::fromUtf8("tab_endDate"));
        calendarEnd = new QCalendarWidget(tab_endDate);
        calendarEnd->setObjectName(QString::fromUtf8("calendarEnd"));
        calendarEnd->setGeometry(QRect(5, 10, 501, 191));
        calendarEnd->setLocale(QLocale(QLocale::English, QLocale::Europe));
        calendarEnd->setGridVisible(true);
        tab_date->addTab(tab_endDate, QString());
        layoutWidget_2 = new QWidget(tab);
        layoutWidget_2->setObjectName(QString::fromUtf8("layoutWidget_2"));
        layoutWidget_2->setGeometry(QRect(10, 130, 233, 19));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget_2);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(layoutWidget_2);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_2->addWidget(label_3);

        label_endDate = new QLabel(layoutWidget_2);
        label_endDate->setObjectName(QString::fromUtf8("label_endDate"));
        label_endDate->setMinimumSize(QSize(150, 0));
        label_endDate->setBaseSize(QSize(30, 0));

        horizontalLayout_2->addWidget(label_endDate);

        layoutWidget_3 = new QWidget(tab);
        layoutWidget_3->setObjectName(QString::fromUtf8("layoutWidget_3"));
        layoutWidget_3->setGeometry(QRect(10, 20, 88, 50));
        verticalLayout = new QVBoxLayout(layoutWidget_3);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label_5 = new QLabel(layoutWidget_3);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        verticalLayout->addWidget(label_5);

        comboBoxClients = new QComboBox(layoutWidget_3);
        comboBoxClients->setObjectName(QString::fromUtf8("comboBoxClients"));

        verticalLayout->addWidget(comboBoxClients);

        btnGenerate = new QPushButton(tab);
        btnGenerate->setObjectName(QString::fromUtf8("btnGenerate"));
        btnGenerate->setGeometry(QRect(420, 0, 89, 25));
        tabWidget->addTab(tab, QString());
        tab_format = new QWidget();
        tab_format->setObjectName(QString::fromUtf8("tab_format"));
        splitter = new QSplitter(tab_format);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setGeometry(QRect(0, 0, 511, 391));
        splitter->setOrientation(Qt::Vertical);
        widget = new QWidget(splitter);
        widget->setObjectName(QString::fromUtf8("widget"));
        horizontalLayout_7 = new QHBoxLayout(widget);
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        horizontalLayout_7->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_6 = new QLabel(widget);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        horizontalLayout_3->addWidget(label_6);

        lineEdit_tax = new QLineEdit(widget);
        lineEdit_tax->setObjectName(QString::fromUtf8("lineEdit_tax"));
        lineEdit_tax->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_3->addWidget(lineEdit_tax);


        horizontalLayout_7->addLayout(horizontalLayout_3);

        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        label_7 = new QLabel(widget);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        horizontalLayout_4->addWidget(label_7);

        lineEdit_userCurrency = new QLineEdit(widget);
        lineEdit_userCurrency->setObjectName(QString::fromUtf8("lineEdit_userCurrency"));
        lineEdit_userCurrency->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_4->addWidget(lineEdit_userCurrency);


        verticalLayout_6->addLayout(horizontalLayout_4);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        label_8 = new QLabel(widget);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        horizontalLayout_5->addWidget(label_8);

        lineEdit_clientCurrency = new QLineEdit(widget);
        lineEdit_clientCurrency->setObjectName(QString::fromUtf8("lineEdit_clientCurrency"));
        lineEdit_clientCurrency->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_5->addWidget(lineEdit_clientCurrency);


        verticalLayout_6->addLayout(horizontalLayout_5);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        label_9 = new QLabel(widget);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        horizontalLayout_6->addWidget(label_9);

        lineEdit_exchange = new QLineEdit(widget);
        lineEdit_exchange->setObjectName(QString::fromUtf8("lineEdit_exchange"));
        lineEdit_exchange->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_6->addWidget(lineEdit_exchange);


        verticalLayout_6->addLayout(horizontalLayout_6);


        horizontalLayout_7->addLayout(verticalLayout_6);

        splitter->addWidget(widget);
        widget1 = new QWidget(splitter);
        widget1->setObjectName(QString::fromUtf8("widget1"));
        verticalLayout_5 = new QVBoxLayout(widget1);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(0, 0, 0, 0);
        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        line = new QFrame(widget1);
        line->setObjectName(QString::fromUtf8("line"));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        verticalLayout_2->addWidget(line);

        label_2 = new QLabel(widget1);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout_2->addWidget(label_2);

        textEdit_header = new QTextEdit(widget1);
        textEdit_header->setObjectName(QString::fromUtf8("textEdit_header"));

        verticalLayout_2->addWidget(textEdit_header);


        verticalLayout_4->addLayout(verticalLayout_2);

        line_3 = new QFrame(widget1);
        line_3->setObjectName(QString::fromUtf8("line_3"));
        line_3->setFrameShape(QFrame::HLine);
        line_3->setFrameShadow(QFrame::Sunken);

        verticalLayout_4->addWidget(line_3);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        label_4 = new QLabel(widget1);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        verticalLayout_3->addWidget(label_4);

        textEdit_footer = new QTextEdit(widget1);
        textEdit_footer->setObjectName(QString::fromUtf8("textEdit_footer"));

        verticalLayout_3->addWidget(textEdit_footer);


        verticalLayout_4->addLayout(verticalLayout_3);


        verticalLayout_5->addLayout(verticalLayout_4);

        line_2 = new QFrame(widget1);
        line_2->setObjectName(QString::fromUtf8("line_2"));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);

        verticalLayout_5->addWidget(line_2);

        btnSaveSettings = new QPushButton(widget1);
        btnSaveSettings->setObjectName(QString::fromUtf8("btnSaveSettings"));

        verticalLayout_5->addWidget(btnSaveSettings);

        splitter->addWidget(widget1);
        tabWidget->addTab(tab_format, QString());

        retranslateUi(Invoice);

        tabWidget->setCurrentIndex(0);
        tab_date->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(Invoice);
    } // setupUi

    void retranslateUi(QWidget *Invoice)
    {
        Invoice->setWindowTitle(QCoreApplication::translate("Invoice", "Invoice", nullptr));
        label->setText(QCoreApplication::translate("Invoice", "Start date:", nullptr));
        label_startDate->setText(QString());
        tab_date->setTabText(tab_date->indexOf(tab_startDate), QCoreApplication::translate("Invoice", "Start date", nullptr));
        tab_date->setTabText(tab_date->indexOf(tab_endDate), QCoreApplication::translate("Invoice", "End date", nullptr));
        label_3->setText(QCoreApplication::translate("Invoice", "End date:", nullptr));
        label_endDate->setText(QString());
        label_5->setText(QCoreApplication::translate("Invoice", "Client", nullptr));
        btnGenerate->setText(QCoreApplication::translate("Invoice", "Generate", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QCoreApplication::translate("Invoice", "Select", nullptr));
        label_6->setText(QCoreApplication::translate("Invoice", "Tax:", nullptr));
        lineEdit_tax->setText(QCoreApplication::translate("Invoice", "19", nullptr));
        label_7->setText(QCoreApplication::translate("Invoice", "User Currency:", nullptr));
        lineEdit_userCurrency->setText(QCoreApplication::translate("Invoice", "$", nullptr));
        label_8->setText(QCoreApplication::translate("Invoice", "Client Currency:", nullptr));
        lineEdit_clientCurrency->setText(QCoreApplication::translate("Invoice", "$", nullptr));
        label_9->setText(QCoreApplication::translate("Invoice", "Exchange rate:", nullptr));
        lineEdit_exchange->setText(QCoreApplication::translate("Invoice", "0", nullptr));
        label_2->setText(QCoreApplication::translate("Invoice", "Header:", nullptr));
        textEdit_header->setHtml(QCoreApplication::translate("Invoice", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Sender Name</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Street 34/56</p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">12345 City</p></body></html>", nullptr));
        label_4->setText(QCoreApplication::translate("Invoice", "Footer:", nullptr));
        textEdit_footer->setHtml(QCoreApplication::translate("Invoice", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Ubuntu'; font-size:11pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Sincerly</p></body></html>", nullptr));
        btnSaveSettings->setText(QCoreApplication::translate("Invoice", "Save", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_format), QCoreApplication::translate("Invoice", "Format", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Invoice: public Ui_Invoice {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_INVOICE_H
