/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.2.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionOverview;
    QAction *actionCreate_Invoice;
    QAction *actionPort;
    QAction *actionInfo;
    QWidget *centralwidget;
    QWidget *layoutWidget_2;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_5;
    QLabel *label_taskstarted;
    QWidget *layoutWidget_3;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_7;
    QLabel *label_moneyearned;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_4;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLabel *label_currentclient;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_3;
    QLabel *label_currenttask;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout_6;
    QPushButton *startTaskBtn;
    QPushButton *stopTaskBtn;
    QProgressBar *progressBar;
    QMenuBar *menubar;
    QMenu *menuOptions;
    QMenu *menuUSB;
    QMenu *menuHelp;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(470, 300);
        actionOverview = new QAction(MainWindow);
        actionOverview->setObjectName(QString::fromUtf8("actionOverview"));
        actionCreate_Invoice = new QAction(MainWindow);
        actionCreate_Invoice->setObjectName(QString::fromUtf8("actionCreate_Invoice"));
        actionPort = new QAction(MainWindow);
        actionPort->setObjectName(QString::fromUtf8("actionPort"));
        actionInfo = new QAction(MainWindow);
        actionInfo->setObjectName(QString::fromUtf8("actionInfo"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        layoutWidget_2 = new QWidget(centralwidget);
        layoutWidget_2->setObjectName(QString::fromUtf8("layoutWidget_2"));
        layoutWidget_2->setGeometry(QRect(10, 70, 350, 19));
        horizontalLayout_3 = new QHBoxLayout(layoutWidget_2);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        label_5 = new QLabel(layoutWidget_2);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        horizontalLayout_3->addWidget(label_5);

        label_taskstarted = new QLabel(layoutWidget_2);
        label_taskstarted->setObjectName(QString::fromUtf8("label_taskstarted"));
        QSizePolicy sizePolicy(QSizePolicy::Maximum, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(label_taskstarted->sizePolicy().hasHeightForWidth());
        label_taskstarted->setSizePolicy(sizePolicy);
        label_taskstarted->setMaximumSize(QSize(255, 16777215));
        label_taskstarted->setAlignment(Qt::AlignJustify|Qt::AlignVCenter);

        horizontalLayout_3->addWidget(label_taskstarted);

        layoutWidget_3 = new QWidget(centralwidget);
        layoutWidget_3->setObjectName(QString::fromUtf8("layoutWidget_3"));
        layoutWidget_3->setGeometry(QRect(10, 100, 215, 19));
        horizontalLayout_5 = new QHBoxLayout(layoutWidget_3);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        label_7 = new QLabel(layoutWidget_3);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        horizontalLayout_5->addWidget(label_7);

        label_moneyearned = new QLabel(layoutWidget_3);
        label_moneyearned->setObjectName(QString::fromUtf8("label_moneyearned"));

        horizontalLayout_5->addWidget(label_moneyearned);

        layoutWidget = new QWidget(centralwidget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 30, 424, 21));
        horizontalLayout_4 = new QHBoxLayout(layoutWidget);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        label_currentclient = new QLabel(layoutWidget);
        label_currentclient->setObjectName(QString::fromUtf8("label_currentclient"));

        horizontalLayout->addWidget(label_currentclient);


        horizontalLayout_4->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_2->addWidget(label_3);

        label_currenttask = new QLabel(layoutWidget);
        label_currenttask->setObjectName(QString::fromUtf8("label_currenttask"));

        horizontalLayout_2->addWidget(label_currenttask);


        horizontalLayout_4->addLayout(horizontalLayout_2);

        layoutWidget1 = new QWidget(centralwidget);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(130, 190, 186, 27));
        horizontalLayout_6 = new QHBoxLayout(layoutWidget1);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        horizontalLayout_6->setContentsMargins(0, 0, 0, 0);
        startTaskBtn = new QPushButton(layoutWidget1);
        startTaskBtn->setObjectName(QString::fromUtf8("startTaskBtn"));

        horizontalLayout_6->addWidget(startTaskBtn);

        stopTaskBtn = new QPushButton(layoutWidget1);
        stopTaskBtn->setObjectName(QString::fromUtf8("stopTaskBtn"));

        horizontalLayout_6->addWidget(stopTaskBtn);

        progressBar = new QProgressBar(centralwidget);
        progressBar->setObjectName(QString::fromUtf8("progressBar"));
        progressBar->setGeometry(QRect(10, 140, 441, 23));
        progressBar->setMaximum(60);
        progressBar->setValue(0);
        progressBar->setAlignment(Qt::AlignCenter);
        progressBar->setTextVisible(true);
        progressBar->setInvertedAppearance(false);
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 470, 22));
        menuOptions = new QMenu(menubar);
        menuOptions->setObjectName(QString::fromUtf8("menuOptions"));
        menuUSB = new QMenu(menuOptions);
        menuUSB->setObjectName(QString::fromUtf8("menuUSB"));
        menuHelp = new QMenu(menubar);
        menuHelp->setObjectName(QString::fromUtf8("menuHelp"));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        menubar->addAction(menuOptions->menuAction());
        menubar->addAction(menuHelp->menuAction());
        menuOptions->addAction(menuUSB->menuAction());
        menuOptions->addSeparator();
        menuOptions->addSeparator();
        menuOptions->addAction(actionOverview);
        menuOptions->addAction(actionCreate_Invoice);
        menuUSB->addAction(actionPort);
        menuHelp->addAction(actionInfo);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "TimeIsMoney", nullptr));
        actionOverview->setText(QCoreApplication::translate("MainWindow", "Overview", nullptr));
        actionCreate_Invoice->setText(QCoreApplication::translate("MainWindow", "Create Invoice", nullptr));
        actionPort->setText(QCoreApplication::translate("MainWindow", "Port", nullptr));
        actionInfo->setText(QCoreApplication::translate("MainWindow", "Info", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "Task started:", nullptr));
        label_taskstarted->setText(QString());
        label_7->setText(QCoreApplication::translate("MainWindow", "Money earned:", nullptr));
        label_moneyearned->setText(QString());
        label->setText(QCoreApplication::translate("MainWindow", "Current Client:", nullptr));
        label_currentclient->setText(QString());
        label_3->setText(QCoreApplication::translate("MainWindow", "Current Task:", nullptr));
        label_currenttask->setText(QString());
        startTaskBtn->setText(QCoreApplication::translate("MainWindow", "Start", nullptr));
#if QT_CONFIG(shortcut)
        startTaskBtn->setShortcut(QCoreApplication::translate("MainWindow", "Alt+S", nullptr));
#endif // QT_CONFIG(shortcut)
        stopTaskBtn->setText(QCoreApplication::translate("MainWindow", "Stop", nullptr));
#if QT_CONFIG(shortcut)
        stopTaskBtn->setShortcut(QCoreApplication::translate("MainWindow", "Alt+E", nullptr));
#endif // QT_CONFIG(shortcut)
        progressBar->setFormat(QCoreApplication::translate("MainWindow", "0h %vmin", nullptr));
        menuOptions->setTitle(QCoreApplication::translate("MainWindow", "Options", nullptr));
        menuUSB->setTitle(QCoreApplication::translate("MainWindow", "USB", nullptr));
        menuHelp->setTitle(QCoreApplication::translate("MainWindow", "Help", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
